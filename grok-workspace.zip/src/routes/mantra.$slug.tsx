import { useEffect, useState } from "react";
import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, Check, Copy, Heart } from "lucide-react";
import { JapaMala } from "@/components/japa-mala";
import { SiteFooter, SiteHeader } from "@/components/site-header";
import { Button } from "@/components/ui/button";
import { categories } from "@/data/categories";
import { getMantra, mantras } from "@/data/mantras";
import { useFavorites } from "@/lib/favorites";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/mantra/$slug")({
  loader: ({ params }) => {
    const mantra = getMantra(params.slug);
    if (!mantra) throw notFound();
    return mantra;
  },
  component: MantraPage,
  notFoundComponent: MantraMissing,
});

function MantraMissing() {
  return (
    <div className="min-h-dvh bg-bg text-ink">
      <SiteHeader />
      <main className="mx-auto max-w-xl px-4 py-20 text-center">
        <p className="font-display text-3xl">यह मंत्र कोश में नहीं मिला</p>
        <Link to="/" className="mt-6 inline-flex h-11 items-center text-accent">
          वापस संग्रह पर
        </Link>
      </main>
    </div>
  );
}

function MantraPage() {
  const mantra = Route.useLoaderData();

  const cat = categories.find((c) => c.id === mantra.category);
  const related = mantras
    .filter((m) => m.category === mantra.category && m.slug !== mantra.slug)
    .slice(0, 3);
  const toggle = useFavorites((s) => s.toggle);
  const ids = useFavorites((s) => s.ids);
  const [mounted, setMounted] = useState(false);
  const [copied, setCopied] = useState(false);
  useEffect(() => setMounted(true), []);
  const saved = mounted && ids.includes(mantra.slug);

  async function copyText() {
    await navigator.clipboard.writeText(mantra.sanskrit);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1600);
  }

  return (
    <div className="min-h-dvh bg-bg text-ink">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-12">
        <Link
          to="/"
          search={{ cat: mantra.category, q: undefined }}
          className="inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-ink"
        >
          <ArrowLeft className="size-4" strokeWidth={1.75} />
          {cat?.title ?? "कोश"}
        </Link>

        <div className="mt-8 grid gap-10 lg:grid-cols-12">
          <article className="lg:col-span-7">
            <p className="text-xs font-medium tracking-kicker text-muted uppercase">
              {mantra.source}
            </p>
            <h1 className="mt-3 font-display text-4xl tracking-tight sm:text-5xl">
              {mantra.title}
            </h1>
            <div className="mt-8 rounded-xl bg-surface px-5 py-6 shadow-[var(--shadow-border)] sm:px-8 sm:py-8">
              <p className="mantra-text font-display text-2xl leading-relaxed sm:text-3xl">
                {mantra.sanskrit}
              </p>
            </div>
            <p className="mt-5 text-sm leading-relaxed text-muted italic">
              {mantra.iast}
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              <Button type="button" variant="outline" onClick={copyText}>
                {copied ? (
                  <Check className="size-4" strokeWidth={1.75} />
                ) : (
                  <Copy className="size-4" strokeWidth={1.75} />
                )}
                {copied ? "नकल हो गया" : "देवनागरी नकल करें"}
              </Button>
              <Button
                type="button"
                variant={saved ? "default" : "outline"}
                onClick={() => toggle(mantra.slug)}
              >
                <Heart
                  className={cn("size-4", saved && "fill-current")}
                  strokeWidth={1.75}
                />
                {saved ? "सहेजा" : "सहेजें"}
              </Button>
            </div>
            <section className="mt-10">
              <h2 className="font-display text-2xl tracking-tight">अर्थ</h2>
              <p className="mt-3 max-w-prose text-base leading-relaxed text-ink/85">
                {mantra.meaningHi}
              </p>
            </section>
            <section className="mt-8 grid gap-4 sm:grid-cols-2">
              <div className="rounded-lg bg-surface p-4 shadow-[var(--shadow-border)]">
                <p className="text-xs tracking-kicker text-muted uppercase">कब जपें</p>
                <p className="mt-2 text-sm leading-relaxed">{mantra.when}</p>
              </div>
              <div className="rounded-lg bg-surface p-4 shadow-[var(--shadow-border)]">
                <p className="text-xs tracking-kicker text-muted uppercase">
                  एक आवृत्ति
                </p>
                <p className="mt-2 font-display text-2xl tabular-nums">
                  {mantra.jaap}
                </p>
              </div>
            </section>
          </article>
          <aside className="lg:col-span-5">
            <JapaMala target={mantra.jaap} />
            <img
              src={mantra.category === "shanti" ? "/lotus.jpg" : "/diya.jpg"}
              alt=""
              className="mt-6 w-full rounded-xl object-cover outline outline-1 -outline-offset-1 outline-ink/10"
            />
          </aside>
        </div>

        {related.length > 0 ? (
          <section className="mt-16 border-t border-line pt-12">
            <h2 className="font-display text-2xl tracking-tight">इसी श्रेणी में</h2>
            <ul className="mt-6 grid gap-3 sm:grid-cols-3">
              {related.map((m) => (
                <li key={m.slug}>
                  <Link
                    to="/mantra/$slug"
                    params={{ slug: m.slug }}
                    className="block rounded-lg bg-surface p-4 shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]"
                  >
                    <p className="font-display text-lg tracking-tight">{m.title}</p>
                    <p className="mt-1 line-clamp-2 text-sm text-muted">
                      {m.sanskrit.split("\n")[0]}
                    </p>
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        ) : null}
      </main>
      <SiteFooter />
    </div>
  );
}
