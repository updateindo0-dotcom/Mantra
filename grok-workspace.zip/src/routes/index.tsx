import { createFileRoute, Link } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { SiteFooter, SiteHeader } from "@/components/site-header";
import { MantraCard } from "@/components/mantra-card";
import { categories, type CategoryId } from "@/data/categories";
import { featured, mantras, searchMantras } from "@/data/mantras";
import { useFavorites } from "@/lib/favorites";
import { cn } from "@/lib/utils";

type Search = {
  q?: string;
  cat?: string;
};

export const Route = createFileRoute("/")({
  validateSearch: (search: Record<string, unknown>): Search => ({
    q: typeof search.q === "string" ? search.q : undefined,
    cat: typeof search.cat === "string" ? search.cat : undefined,
  }),
  component: Home,
});

function Home() {
  const { q, cat } = Route.useSearch();
  const ids = useFavorites((s) => s.ids);
  const query = q ?? "";
  const active = cat ?? "all";

  let list = query ? searchMantras(query) : mantras;
  if (active === "saved") {
    list = list.filter((m) => ids.includes(m.slug));
  } else if (active !== "all") {
    list = list.filter((m) => m.category === active);
  }

  const catMeta = categories.find((c) => c.id === active);

  return (
    <div className="min-h-dvh bg-bg text-ink">
      <SiteHeader />
      <main>
        <Hero query={query} />
        <section className="border-b border-line">
          <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-10">
            <p className="text-xs font-medium tracking-kicker text-muted uppercase">
              देव · संप्रदाय
            </p>
            <div className="mt-4 flex gap-2 overflow-x-auto pb-1">
              <CatChip to="all" label="सभी" active={active === "all"} />
              <CatChip to="saved" label="सहेजे" active={active === "saved"} />
              {categories.map((c) => (
                <CatChip
                  key={c.id}
                  to={c.id}
                  label={c.title}
                  active={active === c.id}
                />
              ))}
            </div>
          </div>
        </section>

        {active === "all" && !query ? (
          <section className="border-b border-line">
            <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16">
              <p className="text-xs font-medium tracking-kicker text-muted uppercase">
                नित्य स्मरण
              </p>
              <h2 className="mt-3 font-display text-3xl tracking-tight">
                सबसे अधिक जपे जाने वाले
              </h2>
              <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {featured.map((m) => (
                  <MantraCard key={m.slug} mantra={m} />
                ))}
              </div>
            </div>
          </section>
        ) : null}

        <section>
          <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16">
            <p className="text-xs font-medium tracking-kicker text-muted uppercase">
              {active === "saved"
                ? "आपकी माला"
                : catMeta
                  ? catMeta.blurb
                  : query
                    ? "खोज"
                    : "पूरा कोश"}
            </p>
            <h2 className="mt-3 font-display text-3xl tracking-tight">
              {active === "saved"
                ? "सहेजे मंत्र"
                : catMeta
                  ? catMeta.title
                  : query
                    ? `“${query}”`
                    : `${mantras.length} मंत्र`}
            </h2>
            {list.length === 0 ? (
              <p className="mt-8 max-w-md text-muted">
                {active === "saved"
                  ? "अभी कुछ सहेजा नहीं। किसी मंत्र पर हृदय चिह्न दबाएँ।"
                  : "इस खोज से कोई मंत्र नहीं मिला।"}
              </p>
            ) : (
              <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {list.map((m) => (
                  <MantraCard key={m.slug} mantra={m} />
                ))}
              </div>
            )}
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}

function Hero({ query }: { query: string }) {
  const navigate = Route.useNavigate();
  return (
    <section className="border-b border-line">
      <div className="mx-auto grid max-w-6xl lg:grid-cols-12">
        <div className="flex flex-col justify-end px-4 py-10 sm:px-6 sm:py-16 lg:col-span-6 lg:py-20">
          <div className="stagger-in max-w-xl">
            <p className="text-xs font-medium tracking-kicker text-muted uppercase">
              सनातन धर्म · मंत्र संग्रह
            </p>
            <h1 className="mt-4 font-display text-5xl leading-display tracking-tight sm:text-6xl">
              मंत्र कोश
            </h1>
            <p className="mt-5 text-lg leading-relaxed text-muted">
              गायत्री से हनुमान चालीसा तक — देवनागरी, अर्थ, कब जपें, और एक
              माला का स्पर्श-गणना। वेद अनंत हैं; यह नित्य पाठ का द्वार है।
            </p>
            <div className="relative mt-8">
              <Search
                className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted"
                strokeWidth={1.75}
              />
              <input
                type="search"
                name="q"
                value={query}
                placeholder="गायत्री, शिव, शान्ति…"
                aria-label="मंत्र खोजें"
                className="h-12 w-full rounded-md bg-surface pr-4 pl-10 text-base text-ink shadow-[var(--shadow-border)] outline-none placeholder:text-muted focus-visible:ring-2 focus-visible:ring-accent/40"
                onChange={(e) => {
                  const value = e.target.value;
                  void navigate({
                    search: (prev) => ({
                      ...prev,
                      q: value ? value : undefined,
                    }),
                    replace: true,
                  });
                }}
              />
            </div>
            <p className="mt-3 text-sm text-muted">
              लिखते ही सूची छँटती है। श्रेणियाँ नीचे हैं।
            </p>
          </div>
        </div>
        <div className="relative min-h-64 lg:col-span-6 lg:min-h-96">
          <img
            src="/temple.jpg"
            alt="प्रभात में मंदिर का मंडप और दीप"
            className="absolute inset-0 size-full object-cover outline outline-1 -outline-offset-1 outline-ink/10"
          />
        </div>
      </div>
    </section>
  );
}

function CatChip({
  to,
  label,
  active,
}: {
  to: "all" | "saved" | CategoryId;
  label: string;
  active: boolean;
}) {
  return (
    <Link
      to="/"
      search={{ cat: to === "all" ? undefined : to, q: undefined }}
      className={cn(
        "inline-flex h-11 shrink-0 items-center rounded-full px-4 text-sm transition-colors duration-150",
        active
          ? "bg-accent text-accent-fg"
          : "bg-surface text-ink shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
      )}
    >
      {label}
    </Link>
  );
}
