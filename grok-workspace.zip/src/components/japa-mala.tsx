import { useState } from "react";
import { RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";

export function JapaMala({ target }: { target: number }) {
  const [count, setCount] = useState(0);
  const [rounds, setRounds] = useState(0);
  const progress = Math.min(count / target, 1);

  function tap() {
    setCount((c) => {
      const next = c + 1;
      if (next >= target) {
        setRounds((r) => r + 1);
        return 0;
      }
      return next;
    });
  }

  return (
    <div className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] sm:p-6">
      <p className="text-xs font-medium tracking-kicker text-muted uppercase">
        जप माला
      </p>
      <p className="mt-1 text-sm text-muted">
        एक बार थपथपाएँ — {target} पर एक आवृत्ति पूरी।
      </p>
      <button
        type="button"
        onClick={tap}
        className="relative mx-auto mt-6 grid size-44 place-items-center rounded-full bg-bg shadow-[var(--shadow-border)] transition-transform duration-150 ease-out active:scale-[0.96] sm:size-52"
        aria-label="जप जोड़ें"
      >
        <svg
          viewBox="0 0 120 120"
          className="absolute inset-2 size-[calc(100%-16px)] -rotate-90"
          aria-hidden
        >
          <circle
            cx="60"
            cy="60"
            r="52"
            fill="none"
            className="stroke-line"
            strokeWidth="4"
          />
          <circle
            cx="60"
            cy="60"
            r="52"
            fill="none"
            className="stroke-accent"
            strokeWidth="4"
            strokeLinecap="round"
            strokeDasharray={2 * Math.PI * 52}
            strokeDashoffset={(1 - progress) * 2 * Math.PI * 52}
            style={{ transition: "stroke-dashoffset 150ms ease-out" }}
          />
        </svg>
        <span className="relative text-center">
          <span className="block font-display text-5xl tabular-nums leading-none tracking-tight">
            {count}
          </span>
          <span className="mt-2 block text-xs text-muted">/ {target}</span>
        </span>
      </button>
      <div className="mt-5 flex items-center justify-between gap-3">
        <p className="text-sm text-muted">
          आवृत्तियाँ: <span className="tabular-nums text-ink">{rounds}</span>
        </p>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() => {
            setCount(0);
            setRounds(0);
          }}
        >
          <RotateCcw className="size-3.5" strokeWidth={1.75} />
          रीसेट
        </Button>
      </div>
    </div>
  );
}
