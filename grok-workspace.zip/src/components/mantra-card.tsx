import { Link } from "@tanstack/react-router";
import { categories } from "@/data/categories";
import { type Mantra } from "@/data/mantras";

export function MantraCard({ mantra }: { mantra: Mantra }) {
  const cat = categories.find((c) => c.id === mantra.category);
  const preview = mantra.sanskrit.split("\n")[0];

  return (
    <Link
      to="/mantra/$slug"
      params={{ slug: mantra.slug }}
      className="group flex flex-col rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-150 ease-out hover:shadow-[var(--shadow-border-hover)] active:scale-[0.99]"
    >
      <p className="text-xs font-medium tracking-kicker text-muted uppercase">
        {cat?.title}
      </p>
      <h3 className="mt-2 font-display text-xl tracking-tight group-hover:text-accent">
        {mantra.title}
      </h3>
      <p className="mantra-text mt-3 line-clamp-3 text-base text-ink/80">{preview}</p>
      <p className="mt-4 text-sm text-muted">{mantra.source}</p>
    </Link>
  );
}
