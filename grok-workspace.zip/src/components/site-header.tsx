import { Link } from "@tanstack/react-router";
import { Heart } from "lucide-react";

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-30 border-b border-line/80 bg-bg/92 backdrop-blur-sm">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
        <Link to="/" className="flex min-h-11 items-center gap-3">
          <span
            aria-hidden
            className="grid size-9 place-items-center rounded-md bg-accent font-display text-lg leading-none text-accent-fg"
          >
            ॐ
          </span>
          <span className="flex flex-col leading-none">
            <span className="font-display text-lg tracking-tight">मंत्र कोश</span>
            <span className="mt-1 text-xs text-muted">सनातन धर्म · नित्य पाठ</span>
          </span>
        </Link>
        <Link
          to="/"
          search={{ cat: "saved", q: undefined }}
          className="inline-flex h-11 min-h-11 items-center gap-2 rounded-md px-3 text-sm text-muted transition-colors duration-150 hover:bg-ink/5 hover:text-ink"
        >
          <Heart className="size-4" strokeWidth={1.75} />
          सहेजे
        </Link>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="border-t border-line bg-ink text-bg">
      <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
        <p className="font-display text-2xl tracking-tight">मंत्र कोश</p>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed opacity-75">
          सनातन धर्म में मंत्र अनंत हैं। यह कोश नित्य-पाठ के प्रमुख वैदिक, पौराणिक
          और लोक-प्रचलित मंत्रों का संग्रह है — संपूर्ण वेद नहीं। शुद्ध उच्चारण
          गुरु-मुख से श्रेष्ठ है।
        </p>
      </div>
    </footer>
  );
}
