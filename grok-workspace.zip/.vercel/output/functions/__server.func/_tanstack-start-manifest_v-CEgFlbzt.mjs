//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CEgFlbzt.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/mantra/$slug"],
		preloads: [
			"/assets/index-h6hsMapf.js",
			"/assets/createLucideIcon-hrbIcVEz.js",
			"/assets/mantras-CuvjYrrU.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-h6hsMapf.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CdXUkto1.js",
			"/assets/site-header-CvvnEo81.js",
			"/assets/utils-B4_1ab9p.js"
		]
	},
	"/mantra/$slug": {
		filePath: "/workspace/src/routes/mantra.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/mantra._slug-Can-Qbpo.js",
			"/assets/site-header-CvvnEo81.js",
			"/assets/utils-B4_1ab9p.js",
			"/assets/mantra._slug-_MTbJUC-.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
