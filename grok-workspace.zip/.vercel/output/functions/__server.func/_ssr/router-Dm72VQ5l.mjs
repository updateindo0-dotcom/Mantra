import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as createFileRoute, b as useRouter, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, q as notFound, v as createRootRoute, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mantras-BRG6r4XU.js
var mantras = [
	{
		slug: "om",
		title: "ॐकार",
		category: "vedic",
		source: "माण्डूक्य उपनिषद् · भगवद्गीता",
		sanskrit: "ॐ",
		iast: "oṃ",
		meaningHi: "प्रणव — सृष्टि का मूल नाद। अ-उ-म जाग्रत, स्वप्न और सुषुप्ति हैं; मौन तुरीय है। गीता में कृष्ण कहते हैं — मंत्रों में मैं ॐ हूँ।",
		when: "हर जप के आरंभ में, ध्यान और प्राणायाम में।",
		jaap: 108,
		featured: true
	},
	{
		slug: "gayatri",
		title: "गायत्री मंत्र",
		category: "vedic",
		source: "ऋग्वेद ३.६२.१०",
		sanskrit: `ॐ भूर्भुवः स्वः।
तत्सवितुर्वरेण्यं
भर्गो देवस्य धीमहि।
धियो यो नः प्रचोदयात्॥`,
		iast: "oṃ bhūr bhuvaḥ svaḥ tat savitur vareṇyaṃ bhargo devasya dhīmahi dhiyo yo naḥ pracodayāt",
		meaningHi: "हम उस सवितृ के वरणीय तेज का ध्यान करते हैं। वह हमारी बुद्धि को सन्मार्ग पर प्रेरित करे। वेदों की माता कही जाने वाली यह गायत्री संध्या-काल का प्रधान मंत्र है।",
		when: "प्रातः, मध्याह्न और सायं संध्या में। शुद्ध उच्चारण के साथ।",
		jaap: 108,
		featured: true
	},
	{
		slug: "mahamrityunjaya",
		title: "महामृत्युंजय मंत्र",
		category: "shiva",
		source: "ऋग्वेद ७.५९.१२ · यजुर्वेद",
		sanskrit: `ॐ त्र्यम्बकं यजामहे सुगन्धिं पुष्टिवर्धनम्।
उर्वारुकमिव बन्धनान् मृत्योर्मुक्षीय माऽमृतात्॥`,
		iast: "oṃ tryambakaṃ yajāmahe sugandhiṃ puṣṭivardhanam urvārukam iva bandhanān mṛtyor mukṣīya mā'mṛtāt",
		meaningHi: "हम त्रिनेत्र शिव का यजन करते हैं, जो सुगंधित हैं और पुष्टि देते हैं। जैसे पका खीरा बेल से स्वतः छूटता है, वैसे हमें मृत्यु-बंधन से मुक्त करें — अमृत से अलग न करें।",
		when: "आरोग्य, भय और संकट में; प्रातः जप।",
		jaap: 108,
		featured: true
	},
	{
		slug: "purnamadah",
		title: "पूर्णमदः पूर्णमिदम्",
		category: "shanti",
		source: "ईशावास्य उपनिषद् शान्ति मंत्र",
		sanskrit: `ॐ पूर्णमदः पूर्णमिदं पूर्णात्पूर्णमुदच्यते।
पूर्णस्य पूर्णमादाय पूर्णमेवावशिष्यते॥
ॐ शान्तिः शान्तिः शान्तिः॥`,
		iast: "oṃ pūrṇamadaḥ pūrṇamidaṃ pūrṇātpūrṇamudacyate pūrṇasya pūrṇamādāya pūrṇamevāvaśiṣyate",
		meaningHi: "वह पूर्ण है, यह पूर्ण है। पूर्ण से पूर्ण निकलता है, पूर्ण को लेने पर भी पूर्ण ही रहता है। ब्रह्म की अखंडता का मंत्र।",
		when: "स्वाध्याय और यज्ञ के आरंभ-अंत में।",
		jaap: 3
	},
	{
		slug: "saha-navavatu",
		title: "ॐ सह नाववतु",
		category: "shanti",
		source: "तैत्तिरीय · कठ उपनिषद्",
		sanskrit: `ॐ सह नाववतु। सह नौ भुनक्तु।
सह वीर्यं करवावहै।
तेजस्विनावधीतमस्तु मा विद्विषावहै॥
ॐ शान्तिः शान्तिः शान्तिः॥`,
		iast: "oṃ saha nāvavatu saha nau bhunaktu saha vīryaṃ karavāvahai tejasvināvadhītamastu mā vidviṣāvahai",
		meaningHi: "वह हमारी दोनों की रक्षा करे, दोनों का पालन करे। हम साथ बल करें। हमारा अध्ययन तेजस्वी हो, हम द्वेष न करें। गुरु-शिष्य का शान्ति मंत्र।",
		when: "अध्ययन, कक्षा और सत्संग के आरंभ में।",
		jaap: 3
	},
	{
		slug: "asato-ma",
		title: "असतो मा सद्गमय",
		category: "shanti",
		source: "बृहदारण्यक उपनिषद् १.३.२८",
		sanskrit: `असतो मा सद्गमय।
तमसो मा ज्योतिर्गमय।
मृत्योर्मा अमृतं गमय।
ॐ शान्तिः शान्तिः शान्तिः॥`,
		iast: "asato mā sadgamaya tamaso mā jyotirgamaya mṛtyor mā amṛtaṃ gamaya",
		meaningHi: "मुझे असत् से सत् की ओर ले चलो, अंधकार से प्रकाश की ओर, मृत्यु से अमृत की ओर। पावमान मंत्र।",
		when: "संध्या, आरती और अंत्येष्टि सहित हर शान्ति-कामना में।",
		jaap: 11,
		featured: true
	},
	{
		slug: "sarve-bhavantu",
		title: "सर्वे भवन्तु सुखिनः",
		category: "shanti",
		source: "पारंपरिक लोक-शान्ति पाठ",
		sanskrit: `सर्वे भवन्तु सुखिनः सर्वे सन्तु निरामयाः।
सर्वे भद्राणि पश्यन्तु मा कश्चिद्दुःखभाग्भवेत्॥
ॐ शान्तिः शान्तिः शान्तिः॥`,
		iast: "sarve bhavantu sukhinaḥ sarve santu nirāmayāḥ sarve bhadrāṇi paśyantu mā kaścid duḥkhabhāg bhavet",
		meaningHi: "सभी सुखी हों, सभी निरोग हों, सभी कल्याण देखें, कोई दुःख का भागी न हो।",
		when: "विश्व-शान्ति प्रार्थना, सत्संग की समाप्ति पर।",
		jaap: 3,
		featured: true
	},
	{
		slug: "dyauh-shantih",
		title: "द्यौः शान्तिः",
		category: "shanti",
		source: "यजुर्वेद ३६.१७",
		sanskrit: `ॐ द्यौः शान्तिरन्तरिक्षं शान्तिः
पृथिवी शान्तिरापः शान्तिरोषधयः शान्तिः।
वनस्पतयः शान्तिर्विश्वे देवाः शान्तिर्ब्रह्म शान्तिः
सर्वं शान्तिः शान्तिरेव शान्तिः सा मा शान्तिरेधि॥
ॐ शान्तिः शान्तिः शान्तिः॥`,
		iast: "oṃ dyauḥ śāntir antarikṣaṃ śāntiḥ pṛthivī śāntir āpaḥ śāntir oṣadhayaḥ śāntiḥ",
		meaningHi: "द्युलोक, अंतरिक्ष, पृथ्वी, जल, ओषधि, वनस्पति, विश्वेदेव, ब्रह्म — सब में शान्ति हो, वह शान्ति मुझमें आए।",
		when: "यज्ञ, हवन और पर्यावरण-शान्ति के पाठ में।",
		jaap: 1
	},
	{
		slug: "karagre",
		title: "कराग्रे वसते लक्ष्मी",
		category: "nitya",
		source: "नित्य प्रातः स्मरण",
		sanskrit: `कराग्रे वसते लक्ष्मीः करमध्ये सरस्वती।
करमूले तु गोविन्दः प्रभाते करदर्शनम्॥`,
		iast: "karāgre vasate lakṣmīḥ karamadhye sarasvatī karamūle tu govindaḥ prabhāte karadarśanam",
		meaningHi: "अंगूठे के मूल में लक्ष्मी, हथेली में सरस्वती, कलाई में गोविंद। प्रातः अपने हाथ देखना ही यह स्मरण है।",
		when: "जागते ही, बिस्तर से पहले, दोनों हथेलियाँ देखकर।",
		jaap: 1
	},
	{
		slug: "samudra-vasane",
		title: "समुद्रवसने देवि",
		category: "nitya",
		source: "भूमि वंदना",
		sanskrit: `समुद्रवसने देवि पर्वतस्तनमण्डले।
विष्णुपत्नि नमस्तुभ्यं पादस्पर्शं क्षमस्व मे॥`,
		iast: "samudravasane devi parvatastana-maṇḍale viṣṇupatni namastubhyaṃ pādasparśaṃ kṣamasva me",
		meaningHi: "हे समुद्र-वसना, पर्वत-स्तना पृथ्वी, विष्णुपत्नी, तुम्हें नमस्कार। मेरे पैरों के स्पर्श को क्षमा करना।",
		when: "बिस्तर से उतरते समय पृथ्वी पर पहला कदम रखने से पहले।",
		jaap: 1
	},
	{
		slug: "brahmarpanam",
		title: "ब्रह्मार्पणं ब्रह्म हविः",
		category: "nitya",
		source: "भगवद्गीता ४.२४",
		sanskrit: `ब्रह्मार्पणं ब्रह्म हविर्ब्रह्माग्नौ ब्रह्मणा हुतम्।
ब्रह्मैव तेन गन्तव्यं ब्रह्मकर्मसमाधिना॥`,
		iast: "brahmārpaṇaṃ brahma havir brahmāgnau brahmaṇā hutam brahmaiva tena gantavyaṃ brahma-karma-samādhinā",
		meaningHi: "अर्पण ब्रह्म है, हवि ब्रह्म है, अग्नि में ब्रह्म द्वारा हवन ब्रह्म है। ब्रह्मकर्म में स्थित का गंतव्य भी ब्रह्म है। भोजन को यज्ञ बनाना।",
		when: "भोजन आरंभ करने से पहले।",
		jaap: 1
	},
	{
		slug: "tvameva-mata",
		title: "त्वमेव माता",
		category: "nitya",
		source: "पारंपरिक प्रार्थना",
		sanskrit: `त्वमेव माता च पिता त्वमेव।
त्वमेव बन्धुश्च सखा त्वमेव।
त्वमेव विद्या द्रविणं त्वमेव।
त्वमेव सर्वं मम देव देव॥`,
		iast: "tvameva mātā ca pitā tvameva tvameva bandhuś ca sakhā tvameva tvameva vidyā draviṇaṃ tvameva tvameva sarvaṃ mama deva deva",
		meaningHi: "तुम्हीं माता हो, पिता हो, बंधु हो, सखा हो। तुम्हीं विद्या हो, धन हो, हे देव — तुम्हीं मेरे सब हो।",
		when: "आरती के बाद, किसी भी देव-स्मरण की closure पर।",
		jaap: 1
	},
	{
		slug: "shubham-karoti",
		title: "शुभं करोति कल्याणम्",
		category: "nitya",
		source: "दीप-ज्योति मंत्र",
		sanskrit: `शुभं करोति कल्याणमारोग्यं धनसंपदा।
शत्रुबुद्धिविनाशाय दीपज्योतिर्नमोऽस्तु ते॥`,
		iast: "śubhaṃ karoti kalyāṇam ārogyaṃ dhanasampadā śatrubuddhi-vināśāya dīpajyotir namo'stu te",
		meaningHi: "कल्याण, आरोग्य और संपदा देने वाली, शत्रु-बुद्धि का नाश करने वाली दीप-ज्योति — तुम्हें नमस्कार।",
		when: "दीपक जलाते समय संध्या-आरती में।",
		jaap: 1
	},
	{
		slug: "om-gam-ganapataye",
		title: "ॐ गं गणपतये नमः",
		category: "ganesha",
		source: "गणपति अथर्वशीर्ष",
		sanskrit: "ॐ गं गणपतये नमः",
		iast: "oṃ gaṃ gaṇapataye namaḥ",
		meaningHi: "बीज मंत्र — गं। विघ्नहर्ता गणपति को नमस्कार। हर शुभ कार्य से पहले यही बोला जाता है।",
		when: "कार्यारंभ, यात्रा, परीक्षा, पूजा के पहले।",
		jaap: 108,
		featured: true
	},
	{
		slug: "vakratunda",
		title: "वक्रतुण्ड महाकाय",
		category: "ganesha",
		source: "पारंपरिक गणेश वंदना",
		sanskrit: `वक्रतुण्ड महाकाय सूर्यकोटिसमप्रभ।
निर्विघ्नं कुरु मे देव सर्वकार्येषु सर्वदा॥`,
		iast: "vakratuṇḍa mahākāya sūryakoṭi-samaprabha nirvighnaṃ kuru me deva sarvakāryeṣu sarvadā",
		meaningHi: "हे वक्रतुण्ड, महाकाय, करोड़ सूर्यों के समान तेजस्वी — मेरे सब कार्यों में सदा निर्विघ्न करो।",
		when: "पूजा, सभा, लेखन और नए काम के आरंभ में।",
		jaap: 11
	},
	{
		slug: "shuklambaradharam",
		title: "शुक्लाम्बरधरं विष्णुम्",
		category: "ganesha",
		source: "ध्यान श्लोक",
		sanskrit: `शुक्लाम्बरधरं विष्णुं शशिवर्णं चतुर्भुजम्।
प्रसन्नवदनं ध्यायेत् सर्वविघ्नोपशान्तये॥`,
		iast: "śuklāmbaradharaṃ viṣṇuṃ śaśivarṇaṃ caturbhujam prasannavadanaṃ dhyāyet sarvavighnopaśāntaye",
		meaningHi: "श्वेत वस्त्रधारी, शशि-वर्ण, चतुर्भुज, प्रसन्नवदन गणेश/विष्णु का ध्यान — सब विघ्नों की शान्ति के लिए।",
		when: "पूजा-ध्यान के आरंभ में।",
		jaap: 3
	},
	{
		slug: "ganesh-gayatri",
		title: "गणेश गायत्री",
		category: "ganesha",
		source: "गणपति गायत्री",
		sanskrit: `ॐ एकदन्ताय विद्महे वक्रतुण्डाय धीमहि।
तन्नो दन्तिः प्रचोदयात्॥`,
		iast: "oṃ ekadantāya vidmahe vakratuṇḍāya dhīmahi tanno dantiḥ pracodayāt",
		meaningHi: "हम एकदंत को जानते हैं, वक्रतुण्ड का ध्यान करते हैं। वह दंति हमारी बुद्धि को प्रेरित करे।",
		when: "गणेश चतुर्थी और नित्य गणेश जप में।",
		jaap: 108
	},
	{
		slug: "om-namah-shivaya",
		title: "ॐ नमः शिवाय",
		category: "shiva",
		source: "यजुर्वेद · श्री रुद्रम् पञ्चाक्षर",
		sanskrit: "ॐ नमः शिवाय",
		iast: "oṃ namaḥ śivāya",
		meaningHi: "पञ्चाक्षर — न मः शि वा य। शिव को नमस्कार, जो सबमें शुभ के रूप में बसते हैं। शैव संप्रदाय का मूल मंत्र।",
		when: "नित्य जप, सोमवार, प्रदोष, शिवरात्रि।",
		jaap: 108,
		featured: true
	},
	{
		slug: "karpur-gauram",
		title: "कर्पूरगौरं करुणावतारम्",
		category: "shiva",
		source: "शिव ध्यान",
		sanskrit: `कर्पूरगौरं करुणावतारं
संसारसारं भुजगेन्द्रहारम्।
सदावसन्तं हृदयारविन्दे
भवं भवानीसहितं नमामि॥`,
		iast: "karpūragauraṃ karuṇāvatāraṃ saṃsārasāraṃ bhujagendrahāram sadāvasantaṃ hṛdayāravinde bhavaṃ bhavānīsahitaṃ namāmi",
		meaningHi: "कर्पूर-गौर, करुणा के अवतार, संसार के सार, नागराज के हार वाले, हृदय-कमल में सदा वास करने वाले भव-भवानी को नमस्कार।",
		when: "शिव-पूजा और आरती से पहले ध्यान में।",
		jaap: 3
	},
	{
		slug: "shiva-gayatri",
		title: "शिव गायत्री",
		category: "shiva",
		source: "रुद्र गायत्री",
		sanskrit: `ॐ तत्पुरुषाय विद्महे महादेवाय धीमहि।
तन्नो रुद्रः प्रचोदयात्॥`,
		iast: "oṃ tatpuruṣāya vidmahe mahādevāya dhīmahi tanno rudraḥ pracodayāt",
		meaningHi: "हम उस पुरुष को जानते हैं, महादेव का ध्यान करते हैं। रुद्र हमारी बुद्धि को प्रेरित करें।",
		when: "रुद्राभिषेक और सोमवार के जप में।",
		jaap: 108
	},
	{
		slug: "om-namo-narayanaya",
		title: "ॐ नमो नारायणाय",
		category: "vishnu",
		source: "अष्टाक्षर मंत्र",
		sanskrit: "ॐ नमो नारायणाय",
		iast: "oṃ namo nārāyaṇāya",
		meaningHi: "अष्टाक्षर। नारायण — जल में शयन करने वाले, सब प्राणियों के आश्रय — को नमस्कार। वैष्णव दीक्षा का प्रधान मंत्र।",
		when: "नित्य जप, एकादशी, वैकुंठ एकादशी।",
		jaap: 108,
		featured: true
	},
	{
		slug: "om-namo-bhagavate",
		title: "ॐ नमो भगवते वासुदेवाय",
		category: "vishnu",
		source: "द्वादशाक्षर मंत्र",
		sanskrit: "ॐ नमो भगवते वासुदेवाय",
		iast: "oṃ namo bhagavate vāsudevāya",
		meaningHi: "द्वादशाक्षर। भगवान् वासुदेव — कृष्ण, जो सबमें वास करते हैं — को नमस्कार।",
		when: "भागवत पाठ, जन्माष्टमी, नित्य कृष्ण-स्मरण।",
		jaap: 108
	},
	{
		slug: "vishnu-gayatri",
		title: "विष्णु गायत्री",
		category: "vishnu",
		source: "नारायण गायत्री",
		sanskrit: `ॐ नारायणाय विद्महे वासुदेवाय धीमहि।
तन्नो विष्णुः प्रचोदयात्॥`,
		iast: "oṃ nārāyaṇāya vidmahe vāsudevāya dhīmahi tanno viṣṇuḥ pracodayāt",
		meaningHi: "हम नारायण को जानते हैं, वासुदेव का ध्यान करते हैं। विष्णु हमारी बुद्धि को प्रेरित करें।",
		when: "विष्णु-पूजा और संध्या में।",
		jaap: 108
	},
	{
		slug: "hare-krishna",
		title: "हरे कृष्ण महामंत्र",
		category: "vishnu",
		source: "कलि-संतरण उपनिषद् · गौड़ीय परंपरा",
		sanskrit: `हरे कृष्ण हरे कृष्ण
कृष्ण कृष्ण हरे हरे।
हरे राम हरे राम
राम राम हरे हरे॥`,
		iast: "hare kṛṣṇa hare kṛṣṇa kṛṣṇa kṛṣṇa hare hare hare rāma hare rāma rāma rāma hare hare",
		meaningHi: "कलियुग का महामंत्र। हरे (हरि की संबोधन), कृष्ण और राम — नाम-जप से चित्त शुद्ध होता है। गौड़ीय वैष्णव संप्रदाय में यह प्रधान है।",
		when: "हर समय; माला पर १६×१०८, कीर्तन में।",
		jaap: 108,
		featured: true
	},
	{
		slug: "shri-ram-jai-ram",
		title: "श्री राम जय राम",
		category: "vishnu",
		source: "रामनाम · समर्थ रामदास परंपरा",
		sanskrit: "श्री राम जय राम जय जय राम",
		iast: "śrī rāma jaya rāma jaya jaya rāma",
		meaningHi: "तरक-मंत्र। राम नाम का कीर्तन — जय हो, जय हो। संत तुकाराम, समर्थ रामदास और अनंत आचार्यों का प्रिय जप।",
		when: "नित्य रामनाम, रामनवमी, वन-यात्रा, अंतिम समय।",
		jaap: 108
	},
	{
		slug: "om-shri-ramaya",
		title: "ॐ श्री रामाय नमः",
		category: "vishnu",
		source: "राम मूल मंत्र",
		sanskrit: "ॐ श्री रामाय नमः",
		iast: "oṃ śrī rāmāya namaḥ",
		meaningHi: "मर्यादा पुरुषोत्तम राम को नमस्कार।",
		when: "राम-पूजा और नित्य नमस्कार में।",
		jaap: 108
	},
	{
		slug: "achyutam-keshavam",
		title: "अच्युतं केशवं",
		category: "vishnu",
		source: "गोविंद दामोदर स्तोत्रम् (सार)",
		sanskrit: `अच्युतं केशवं रामनारायणं
कृष्णदामोदरं वासुदेवं हरिम्।
श्रीधरं माधवं गोपिकावल्लभं
जानकीनायकं रामचंद्रं भजे॥`,
		iast: "acyutaṃ keśavaṃ rāmanārāyaṇaṃ kṛṣṇadāmodaraṃ vāsudevaṃ harim",
		meaningHi: "अच्युत, केशव, राम-नारायण, कृष्ण-दामोदर, वासुदेव, हरि, श्रीधर, माधव, गोपिका-वल्लभ, जानकीनायक रामचंद्र — उनका भजन।",
		when: "नाम-स्मरण और संध्या कीर्तन में।",
		jaap: 11
	},
	{
		slug: "sarva-mangala",
		title: "सर्वमङ्गलमाङ्गल्ये",
		category: "devi",
		source: "दुर्गासप्तशती · दुर्गा स्तोत्र",
		sanskrit: `सर्वमङ्गलमाङ्गल्ये शिवे सर्वार्थसाधिके।
शरण्ये त्र्यम्बके गौरि नारायणि नमोऽस्तु ते॥`,
		iast: "sarvamaṅgala-māṅgalye śive sarvārthasādhike śaraṇye tryambake gauri nārāyaṇi namo'stu te",
		meaningHi: "सब मंगलों की मंगल, शिवा, सब अर्थों की साधिका, शरण्या, त्र्यम्बका, गौरी, नारायणी — तुम्हें नमस्कार।",
		when: "नवरात्र, दुर्गा-पूजा, संकट में देवी-स्मरण।",
		jaap: 108,
		featured: true
	},
	{
		slug: "om-dum-durgayai",
		title: "ॐ दुं दुर्गायै नमः",
		category: "devi",
		source: "दुर्गा बीज मंत्र",
		sanskrit: "ॐ दुं दुर्गायै नमः",
		iast: "oṃ duṃ durgāyai namaḥ",
		meaningHi: "दुर्गा का बीज दुं। दुर्गायै नमः — दुर्गति हरणी को नमस्कार।",
		when: "नवरात्र के नित्य जप में।",
		jaap: 108
	},
	{
		slug: "navarna",
		title: "नवर्ण मंत्र",
		category: "devi",
		source: "दुर्गासप्तशती · तंत्र",
		sanskrit: "ॐ ऐं ह्रीं क्लीं चामुण्डायै विच्चे",
		iast: "oṃ aiṃ hrīṃ klīṃ cāmuṇḍāyai vicce",
		meaningHi: "नौ अक्षरों का नवार्ण। ऐं वाग्बीज, ह्रीं मायाबीज, क्लीं कामबीज, चामुण्डा को संबोधित। सप्तशती का मूल मंत्र — गुरु-मुख से दीक्षा श्रेष्ठ।",
		when: "चंडी पाठ के साथ; दीक्षा लेकर जप करना उत्तम।",
		jaap: 108
	},
	{
		slug: "ya-devi",
		title: "या देवी सर्वभूतेषु",
		category: "devi",
		source: "दुर्गासप्तशती ५.१६",
		sanskrit: `या देवी सर्वभूतेषु शक्तिरूपेण संस्थिता।
नमस्तस्यै नमस्तस्यै नमस्तस्यै नमो नमः॥`,
		iast: "yā devī sarvabhūteṣu śaktirūpeṇa saṃsthitā namastasyai namastasyai namastasyai namo namaḥ",
		meaningHi: "जो देवी सब भूतों में शक्ति रूप में स्थित हैं — उन्हें बार-बार नमस्कार। सप्तशती में बुद्धि, निद्रा, क्षुधा आदि रूपों से भी गाया जाता है।",
		when: "नवरात्र के देवी-स्तवन में।",
		jaap: 9
	},
	{
		slug: "om-shreem-mahalakshmyai",
		title: "ॐ श्रीं महालक्ष्म्यै नमः",
		category: "devi",
		source: "लक्ष्मी बीज मंत्र",
		sanskrit: "ॐ श्रीं महालक्ष्म्यै नमः",
		iast: "oṃ śrīṃ mahālakṣmyai namaḥ",
		meaningHi: "श्रीं — लक्ष्मी बीज। महालक्ष्मी को नमस्कार। समृद्धि के साथ सद्गुण की प्रार्थना।",
		when: "शुक्रवार, दीपावली, लक्ष्मी पूजन।",
		jaap: 108
	},
	{
		slug: "lakshmi-bija",
		title: "कमले कमलालये",
		category: "devi",
		source: "महालक्ष्मी मंत्र",
		sanskrit: "ॐ श्रीं ह्रीं श्रीं कमले कमलालये प्रसीद प्रसीद ॐ श्रीं ह्रीं श्रीं महालक्ष्म्यै नमः",
		iast: "oṃ śrīṃ hrīṃ śrīṃ kamale kamalālaye prasīda prasīda mahālakṣmyai namaḥ",
		meaningHi: "कमल में वास करने वाली, कमलालये — प्रसन्न हो। महालक्ष्मी को नमस्कार।",
		when: "दीपावली की रात्रि और शुक्रवार के जप में।",
		jaap: 108
	},
	{
		slug: "om-aim-saraswatyai",
		title: "ॐ ऐं सरस्वत्यै नमः",
		category: "devi",
		source: "सरस्वती बीज मंत्र",
		sanskrit: "ॐ ऐं सरस्वत्यै नमः",
		iast: "oṃ aiṃ sarasvatyai namaḥ",
		meaningHi: "ऐं — वाग्बीज। वाणी, विद्या और कला की अधिष्ठात्री सरस्वती को नमस्कार।",
		when: "अध्ययन से पहले, वसंत पंचमी, परीक्षा काल।",
		jaap: 108
	},
	{
		slug: "saraswati-vandana",
		title: "या कुन्देन्दुतुषारहारधवला",
		category: "devi",
		source: "सरस्वती वंदना",
		sanskrit: `या कुन्देन्दुतुषारहारधवला या शुभ्रवस्त्रावृता
या वीणावरदण्डमण्डितकरा या श्वेतपद्मासना।
या ब्रह्माच्युतशङ्करप्रभृतिभिर्देवैः सदा वन्दिता
सा मां पातु सरस्वती भगवती निःशेषजाड्यापहा॥`,
		iast: "yā kundendu-tuṣārahāra-dhavalā yā śubhravastrāvṛtā yā vīṇāvaradaṇḍa-maṇḍitakarā",
		meaningHi: "कुंद-चंद्र-हिम जैसी धवल, शुभ्र वस्त्र, वीणा और वरद-दंड धारिणी, श्वेत पद्मासना, ब्रह्मा-विष्णु-शंकर से वंदित — वह जड़ता हरने वाली सरस्वती मेरी रक्षा करें।",
		when: "पाठशाला, संगीत और लेखन के आरंभ में।",
		jaap: 3
	},
	{
		slug: "annapurne",
		title: "अन्नपूर्णे सदापूर्णे",
		category: "devi",
		source: "अन्नपूर्णा स्तोत्र (शंकराचार्य)",
		sanskrit: `अन्नपूर्णे सदापूर्णे शङ्करप्राणवल्लभे।
ज्ञानवैराग्यसिद्ध्यर्थं भिक्षां देहि च पार्वति॥`,
		iast: "annapūrṇe sadāpūrṇe śaṅkaraprāṇavallabhe jñānavairāgyasiddhyarthaṃ bhikṣāṃ dehi ca pārvati",
		meaningHi: "हे सदा पूर्ण अन्नपूर्णे, शंकर की प्राणवल्लभा — ज्ञान और वैराग्य की सिद्धि के लिए भिक्षा दो, पार्वति।",
		when: "भोजन से पहले, अन्नपूर्णा-पूजन में।",
		jaap: 11
	},
	{
		slug: "om-hanumate",
		title: "ॐ हनुमते नमः",
		category: "hanuman",
		source: "हनुमान मूल मंत्र",
		sanskrit: "ॐ हनुमते नमः",
		iast: "oṃ hanumate namaḥ",
		meaningHi: "पवनसुत हनुमान को नमस्कार। भय, संकट और आलस्य हरने वाले सेवक-श्रेष्ठ।",
		when: "मंगलवार, शनिवार, संकट में।",
		jaap: 108
	},
	{
		slug: "hanuman-gayatri",
		title: "हनुमान गायत्री",
		category: "hanuman",
		source: "हनुमान गायत्री",
		sanskrit: `ॐ अञ्जनेयाय विद्महे वायुपुत्राय धीमहि।
तन्नो हनुमान् प्रचोदयात्॥`,
		iast: "oṃ añjaneyāya vidmahe vāyuputrāya dhīmahi tanno hanumān pracodayāt",
		meaningHi: "हम अंजनेय को जानते हैं, वायुपुत्र का ध्यान करते हैं। हनुमान हमारी बुद्धि को प्रेरित करें।",
		when: "हनुमान पूजा और चालीसा से पहले।",
		jaap: 108
	},
	{
		slug: "buddhir-balam",
		title: "बुद्धिर्बलं यशो धैर्यम्",
		category: "hanuman",
		source: "हनुमान्-आशीष श्लोक",
		sanskrit: `बुद्धिर्बलं यशो धैर्यं निर्भयत्वमरोगता।
अजाड्यं वाक्पटुत्वं च हनुमत्स्मरणाद्भवेत्॥`,
		iast: "buddhir balaṃ yaśo dhairyaṃ nirbhayatvam arogatā ajāḍyaṃ vākpaṭutvaṃ ca hanumat-smaraṇād bhavet",
		meaningHi: "बुद्धि, बल, यश, धैर्य, निर्भयता, आरोग्य, स्फूर्ति और वाक्पटुता — हनुमान के स्मरण से मिलते हैं।",
		when: "चालीसा के बाद आशीष के रूप में।",
		jaap: 3
	},
	{
		slug: "hanuman-chalisa",
		title: "हनुमान चालीसा",
		category: "hanuman",
		source: "गोस्वामी तुलसीदास",
		sanskrit: `श्रीगुरु चरन सरोज रज निज मनु मुकुरु सुधारि।
बरनउँ रघुबर बिमल जसु जो दायकु फल चारि॥

बुद्धिहीन तनु जानिके सुमिरौं पवनकुमार।
बल बुद्धि बिद्या देहु मोहि हरहु कलेस बिकार॥

जय हनुमान ज्ञान गुन सागर। जय कपीस तिहुँ लोक उजागर॥
राम दूत अतुलित बल धामा। अंजनि पुत्र पवनसुत नामा॥
महाबीर बिक्रम बजरंगी। कुमति निवार सुमति के संगी॥
कंचन बरन बिराज सुबेसा। कानन कुण्डल कुंचित केसा॥
हाथ बज्र औ ध्वजा बिराजै। काँधे मूँज जनेऊ साजै॥
शंकर सुवन केसरी नंदन। तेज प्रताप महा जग वंदन॥
बिद्यावान गुनी अति चातुर। राम काज करिबे को आतुर॥
प्रभु चरित्र सुनिबे को रसिया। राम लखन सीता मन बसिया॥
सूक्ष्म रूप धरि सियहिं दिखावा। बिकट रूप धरि लंक जरावा॥
भीम रूप धरि असुर संहारे। रामचन्द्र के काज सँवारे॥
लाय सञ्जीवन लखन जियाये। श्रीरघुबीर हरषि उर लाये॥
रघुपति कीन्ही बहुत बड़ाई। तुम मम प्रिय भरतहि सम भाई॥
सहस बदन तुम्हरो जस गावैं। अस कहि श्रीपति कंठ लगावैं॥
सनकादिक ब्रह्मादि मुनीसा। नारद सारद सहित अहीसा॥
जम कुबेर दिगपाल जहाँ ते। कबि कोबिद कहि सके कहाँ ते॥
तुम उपकार सुग्रीवहिं कीन्हा। राम मिलाय राज पद दीन्हा॥
तुम्हरो मंत्र बिभीषण माना। लंकेश्वर भए सब जग जाना॥
जुग सहस्र जोजन पर भानु। लील्यो ताहि मधुर फल जानू॥
प्रभु मुद्रिका मेलि मुख माहीं। जलधि लाँघि गये अचरज नाहीं॥
दुर्गम काज जगत के जेते। सुगम अनुग्रह तुम्हरे तेते॥
राम दुआरे तुम रखवारे। होत न आज्ञा बिनु पैसारे॥
सब सुख लहै तुम्हारी सरना। तुम रक्षक काहू को डर ना॥
आपन तेज सम्हारो आपै। तीनों लोक हाँक तें काँपै॥
भूत पिशाच निकट नहिं आवै। महाबीर जब नाम सुनावै॥
नासै रोग हरै सब पीरा। जपत निरंतर हनुमत बीरा॥
संकट तें हनुमान छुड़ावै। मन क्रम बचन ध्यान जो लावै॥
सब पर राम तपस्वी राजा। तिन के काज सकल तुम साजा॥
और मनोरथ जो कोई लावै। सोई अमित जीवन फल पावै॥
चारों जुग परताप तुम्हारा। है परसिद्ध जगत उजियारा॥
साधु संत के तुम रखवारे। असुर निकंदन राम दुलारे॥
अष्ट सिद्धि नौ निधि के दाता। अस बर दीन्ह जानकी माता॥
राम रसायन तुम्हरे पासा। सदा रहो रघुपति के दासा॥
तुम्हरे भजन राम को पावै। जनम जनम के दुख बिसरावै॥
अंत काल रघुबर पुर जाई। जहाँ जन्म हरिभक्त कहाई॥
और देवता चित्त न धरई। हनुमत सेइ सर्ब सुख करई॥
संकट कटै मिटै सब पीरा। जो सुमिरै हनुमत बलबीरा॥
जय जय जय हनुमान गोसाईं। कृपा करहु गुरुदेव की नाईं॥
जो सत बार पाठ कर कोई। छूटहि बंदि महा सुख होई॥
जो यह पढ़ै हनुमान चालीसा। होय सिद्धि साखी गौरीसा॥
तुलसीदास सदा हरि चेरा। कीजै नाथ हृदय महँ डेरा॥

पवनतनय संकट हरन मंगल मूरति रूप।
राम लखन सीता सहित हृदय बसहु सुर भूप॥`,
		iast: "śrīguru carana saroja raja… hanumān cālīsā — tulasīdāsa",
		meaningHi: "तुलसीदास कृत चालीस चौपाइयाँ। हनुमान के बल, विद्या, राम-काज और भक्त-रक्षा का स्तोत्र। मंगलवार-शनिवार का सबसे प्रचलित पाठ।",
		when: "प्रातः या संध्या; मंगलवार व शनिवार विशेष।",
		jaap: 1,
		featured: true
	},
	{
		slug: "om-suryaya",
		title: "ॐ सूर्याय नमः",
		category: "surya",
		source: "सूर्य मूल मंत्र",
		sanskrit: "ॐ सूर्याय नमः",
		iast: "oṃ sūryāya namaḥ",
		meaningHi: "सविता सूर्य को नमस्कार — नेत्र, प्राण और काल के अधिष्ठाता।",
		when: "सूर्योदय पर अर्घ्य देते समय।",
		jaap: 12
	},
	{
		slug: "surya-gayatri",
		title: "सूर्य गायत्री",
		category: "surya",
		source: "आदित्य गायत्री",
		sanskrit: `ॐ भास्कराय विद्महे दिवाकराय धीमहि।
तन्नो सूर्यः प्रचोदयात्॥`,
		iast: "oṃ bhāskarāya vidmahe divākarāya dhīmahi tanno sūryaḥ pracodayāt",
		meaningHi: "हम भास्कर को जानते हैं, दिवाकर का ध्यान करते हैं। सूर्य हमारी बुद्धि को प्रेरित करें।",
		when: "सूर्य नमस्कार और प्रातः अर्घ्य के साथ।",
		jaap: 12
	},
	{
		slug: "aditya-hridayam-open",
		title: "आदित्य हृदयम् (आरंभ)",
		category: "surya",
		source: "वाल्मीकि रामायण · युद्ध काण्ड",
		sanskrit: `ततो युद्धपरिश्रान्तं समरे चिन्तया स्थितम्।
रावणं चाग्रतो दृष्ट्वा युद्धाय समुपस्थितम्॥
दैवतैश्च समागम्य द्रष्टुमभ्यागतो रणम्।
उपागम्याब्रवीद्राममगस्त्यो भगवांस्तदा॥
राम राम महाबाहो शृणु गुह्यं सनातनम्।
येन सर्वानरीन्वत्स समरे विजयिष्यसि॥`,
		iast: "tato yuddhapariśrāntaṃ samare cintayā sthitam rāvaṇaṃ cāgrato dṛṣṭvā… rāma rāma mahābāho śṛṇu guhyaṃ sanātanam",
		meaningHi: "अगस्त्य राम को युद्ध-थके चित्त में आदित्य हृदय का गुह्य सुनाते हैं — जिससे समर में विजय हो। पूरा स्तोत्र रामायण युद्ध काण्ड में है; यहाँ द्वार-श्लोक हैं।",
		when: "रविवार प्रातः, सूर्य नमस्कार के बाद पाठ।",
		jaap: 1
	},
	{
		slug: "gurur-brahma",
		title: "गुरुर्ब्रह्मा गुरुर्विष्णुः",
		category: "guru",
		source: "गुरु स्तोत्र",
		sanskrit: `गुरुर्ब्रह्मा गुरुर्विष्णुर्गुरुर्देवो महेश्वरः।
गुरुः साक्षात् परं ब्रह्म तस्मै श्रीगुरवे नमः॥`,
		iast: "gurur brahmā gurur viṣṇur gurur devo maheśvaraḥ guruḥ sākṣāt paraṃ brahma tasmai śrīgurave namaḥ",
		meaningHi: "गुरु ब्रह्मा हैं, विष्णु हैं, महेश्वर हैं। गुरु साक्षात् परब्रह्म हैं — उन श्रीगुरु को नमस्कार।",
		when: "अध्ययन, दीक्षा और गुरुपूर्णिमा पर।",
		jaap: 11,
		featured: true
	},
	{
		slug: "om-gurave",
		title: "ॐ गुरुवे नमः",
		category: "guru",
		source: "गुरु मूल मंत्र",
		sanskrit: "ॐ गुरुवे नमः",
		iast: "oṃ gurave namaḥ",
		meaningHi: "गुरु तत्त्व को नमस्कार — जो अंधकार से प्रकाश की ओर ले जाते हैं।",
		when: "नित्य प्रातः गुरु-स्मरण में।",
		jaap: 108
	},
	{
		slug: "om-shanti",
		title: "ॐ शान्तिः शान्तिः शान्तिः",
		category: "shanti",
		source: "वैदिक समापन",
		sanskrit: "ॐ शान्तिः शान्तिः शान्तिः",
		iast: "oṃ śāntiḥ śāntiḥ śāntiḥ",
		meaningHi: "तीन बार शान्ति — अधिदैविक, अधिभौतिक, अध्यात्मिक तापों की शान्ति। हर वैदिक पाठ का विराम।",
		when: "किसी भी मंत्र या सत्संग की समाप्ति पर।",
		jaap: 3
	},
	{
		slug: "mangalam-bhagavan",
		title: "मङ्गलं भगवान् विष्णुः",
		category: "vishnu",
		source: "मंगल श्लोक",
		sanskrit: `मङ्गलं भगवान् विष्णुर्मङ्गलं गरुडध्वजः।
मङ्गलं पुण्डरीकाक्षो मङ्गलायतनं हरिः॥`,
		iast: "maṅgalaṃ bhagavān viṣṇur maṅgalaṃ garuḍadhvajaḥ maṅgalaṃ puṇḍarīkākṣo maṅgalāyatanaṃ hariḥ",
		meaningHi: "भगवान् विष्णु मंगल हैं, गरुडध्वज मंगल हैं, पुण्डरीकाक्ष मंगल हैं, हरि मंगल के आयतन हैं।",
		when: "शुभ कार्य, विवाह और यात्रा के मंगल-वचन में।",
		jaap: 3
	},
	{
		slug: "durga-gayatri",
		title: "दुर्गा गायत्री",
		category: "devi",
		source: "देवी गायत्री",
		sanskrit: `ॐ गिरिजायै विद्महे शिवप्रियायै धीमहि।
तन्नो दुर्गा प्रचोदयात्॥`,
		iast: "oṃ girijāyai vidmahe śivapriyāyai dhīmahi tanno durgā pracodayāt",
		meaningHi: "हम गिरिजा को जानते हैं, शिवप्रिया का ध्यान करते हैं। दुर्गा हमारी बुद्धि को प्रेरित करें।",
		when: "नवरात्र के गायत्री-जप में।",
		jaap: 108
	},
	{
		slug: "lakshmi-gayatri",
		title: "लक्ष्मी गायत्री",
		category: "devi",
		source: "महालक्ष्मी गायत्री",
		sanskrit: `ॐ महादेव्यै च विद्महे विष्णुपत्न्यै च धीमहि।
तन्नो लक्ष्मीः प्रचोदयात्॥`,
		iast: "oṃ mahādevyai ca vidmahe viṣṇupatnyai ca dhīmahi tanno lakṣmīḥ pracodayāt",
		meaningHi: "हम महादेवी को जानते हैं, विष्णुपत्नी का ध्यान करते हैं। लक्ष्मी हमारी बुद्धि को प्रेरित करें।",
		when: "शुक्रवार और दीपावली के जप में।",
		jaap: 108
	}
];
function getMantra(slug) {
	return mantras.find((m) => m.slug === slug);
}
function searchMantras(q) {
	const n = q.trim().toLowerCase();
	if (!n) return mantras;
	return mantras.filter((m) => {
		return `${m.title} ${m.sanskrit} ${m.iast} ${m.meaningHi} ${m.source}`.toLowerCase().includes(n);
	});
}
var featured = mantras.filter((m) => m.featured);
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-Dm72VQ5l.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-jJqHtozz.css";
var APP_NAME = "मंत्र कोश";
var Route$2 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "सनातन धर्म के प्रमुख मंत्र — देवनागरी, अर्थ, जप और नित्य पाठ। गायत्री, महामृत्युंजय, हनुमान चालीसा और देवी-देवताओं के मंत्र।"
			},
			{
				name: "theme-color",
				content: "#1c1410"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600&family=Fraunces:opsz,wght@9..144,500;9..144,600&family=Noto+Sans+Devanagari:wght@400;500;600&family=Noto+Serif+Devanagari:wght@500;600;700&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "hi",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-bg font-sans text-ink",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	})
});
var $$splitComponentImporter$1 = () => import("./routes-BlIM0bHO.mjs");
var Route$1 = createFileRoute("/")({
	validateSearch: (search) => ({
		q: typeof search.q === "string" ? search.q : void 0,
		cat: typeof search.cat === "string" ? search.cat : void 0
	}),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitNotFoundComponentImporter = () => import("./mantra._slug-CqQ5cUii.mjs");
var $$splitComponentImporter = () => import("./mantra._slug-DzR_gZ1j.mjs");
var Route = createFileRoute("/mantra/$slug")({
	loader: ({ params }) => {
		const mantra = getMantra(params.slug);
		if (!mantra) throw notFound();
		return mantra;
	},
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent")
});
var rootRouteChildren = {
	IndexRoute: Route$1.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$2
	}),
	MantraSlugRoute: Route.update({
		id: "/mantra/$slug",
		path: "/mantra/$slug",
		getParentRoute: () => Route$2
	})
};
var routeTree = Route$2._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { mantras as a, featured as i, Route as n, searchMantras as o, Route$1 as r, router_exports as t };
