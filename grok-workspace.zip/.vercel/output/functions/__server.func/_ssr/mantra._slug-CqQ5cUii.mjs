import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as SiteHeader } from "./site-header-C_hDHpPg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mantra._slug-CqQ5cUii.js
var import_jsx_runtime = require_jsx_runtime();
function MantraMissing() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-xl px-4 py-20 text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-3xl",
				children: "यह मंत्र कोश में नहीं मिला"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-6 inline-flex h-11 items-center text-accent",
				children: "वापस संग्रह पर"
			})]
		})]
	});
}
//#endregion
export { MantraMissing as notFoundComponent };
