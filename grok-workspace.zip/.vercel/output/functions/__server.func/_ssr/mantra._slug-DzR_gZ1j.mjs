import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Copy, i as Heart, o as Check, r as RotateCcw, s as ArrowLeft } from "../_libs/lucide-react.mjs";
import { n as SiteHeader, t as SiteFooter } from "./site-header-C_hDHpPg.mjs";
import { a as mantras, n as Route } from "./router-Dm72VQ5l.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as cn, r as useFavorites, t as categories } from "./utils-CkWN9tQQ.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mantra._slug-DzR_gZ1j.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,color] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40 disabled:pointer-events-none disabled:opacity-50 active:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			ghost: "text-muted hover:bg-ink/5 hover:text-ink",
			outline: "bg-surface text-ink shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]"
		},
		size: {
			default: "h-11 min-h-11 px-4",
			sm: "h-9 min-h-9 px-3",
			lg: "h-12 min-h-12 px-5"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		ref,
		...props
	});
});
Button.displayName = "Button";
function JapaMala({ target }) {
	const [count, setCount] = (0, import_react.useState)(0);
	const [rounds, setRounds] = (0, import_react.useState)(0);
	const progress = Math.min(count / target, 1);
	function tap() {
		setCount((c) => {
			const next = c + 1;
			if (next >= target) {
				setRounds((r) => r + 1);
				return 0;
			}
			return next;
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-kicker text-muted uppercase",
				children: "जप माला"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: [
					"एक बार थपथपाएँ — ",
					target,
					" पर एक आवृत्ति पूरी।"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: tap,
				className: "relative mx-auto mt-6 grid size-44 place-items-center rounded-full bg-bg shadow-[var(--shadow-border)] transition-transform duration-150 ease-out active:scale-[0.96] sm:size-52",
				"aria-label": "जप जोड़ें",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: "0 0 120 120",
					className: "absolute inset-2 size-[calc(100%-16px)] -rotate-90",
					"aria-hidden": true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "60",
						cy: "60",
						r: "52",
						fill: "none",
						className: "stroke-line",
						strokeWidth: "4"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "60",
						cy: "60",
						r: "52",
						fill: "none",
						className: "stroke-accent",
						strokeWidth: "4",
						strokeLinecap: "round",
						strokeDasharray: 2 * Math.PI * 52,
						strokeDashoffset: (1 - progress) * 2 * Math.PI * 52,
						style: { transition: "stroke-dashoffset 150ms ease-out" }
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "relative text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-display text-5xl tabular-nums leading-none tracking-tight",
						children: count
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-2 block text-xs text-muted",
						children: ["/ ", target]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: ["आवृत्तियाँ: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-ink",
						children: rounds
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "ghost",
					size: "sm",
					onClick: () => {
						setCount(0);
						setRounds(0);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
						className: "size-3.5",
						strokeWidth: 1.75
					}), "रीसेट"]
				})]
			})
		]
	});
}
function MantraPage() {
	const mantra = Route.useLoaderData();
	const cat = categories.find((c) => c.id === mantra.category);
	const related = mantras.filter((m) => m.category === mantra.category && m.slug !== mantra.slug).slice(0, 3);
	const toggle = useFavorites((s) => s.toggle);
	const ids = useFavorites((s) => s.ids);
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	const saved = mounted && ids.includes(mantra.slug);
	async function copyText() {
		await navigator.clipboard.writeText(mantra.sanskrit);
		setCopied(true);
		window.setTimeout(() => setCopied(false), 1600);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						search: {
							cat: mantra.category,
							q: void 0
						},
						className: "inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
							className: "size-4",
							strokeWidth: 1.75
						}), cat?.title ?? "कोश"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 grid gap-10 lg:grid-cols-12",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "lg:col-span-7",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium tracking-kicker text-muted uppercase",
									children: mantra.source
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "mt-3 font-display text-4xl tracking-tight sm:text-5xl",
									children: mantra.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-8 rounded-xl bg-surface px-5 py-6 shadow-[var(--shadow-border)] sm:px-8 sm:py-8",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mantra-text font-display text-2xl leading-relaxed sm:text-3xl",
										children: mantra.sanskrit
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 text-sm leading-relaxed text-muted italic",
									children: mantra.iast
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-6 flex flex-wrap gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "button",
										variant: "outline",
										onClick: copyText,
										children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
											className: "size-4",
											strokeWidth: 1.75
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
											className: "size-4",
											strokeWidth: 1.75
										}), copied ? "नकल हो गया" : "देवनागरी नकल करें"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "button",
										variant: saved ? "default" : "outline",
										onClick: () => toggle(mantra.slug),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
											className: cn("size-4", saved && "fill-current"),
											strokeWidth: 1.75
										}), saved ? "सहेजा" : "सहेजें"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
									className: "mt-10",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-2xl tracking-tight",
										children: "अर्थ"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 max-w-prose text-base leading-relaxed text-ink/85",
										children: mantra.meaningHi
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
									className: "mt-8 grid gap-4 sm:grid-cols-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-lg bg-surface p-4 shadow-[var(--shadow-border)]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs tracking-kicker text-muted uppercase",
											children: "कब जपें"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm leading-relaxed",
											children: mantra.when
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-lg bg-surface p-4 shadow-[var(--shadow-border)]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs tracking-kicker text-muted uppercase",
											children: "एक आवृत्ति"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 font-display text-2xl tabular-nums",
											children: mantra.jaap
										})]
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
							className: "lg:col-span-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JapaMala, { target: mantra.jaap }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: mantra.category === "shanti" ? "/lotus.jpg" : "/diya.jpg",
								alt: "",
								className: "mt-6 w-full rounded-xl object-cover outline outline-1 -outline-offset-1 outline-ink/10"
							})]
						})]
					}),
					related.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-16 border-t border-line pt-12",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl tracking-tight",
							children: "इसी श्रेणी में"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-6 grid gap-3 sm:grid-cols-3",
							children: related.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/mantra/$slug",
								params: { slug: m.slug },
								className: "block rounded-lg bg-surface p-4 shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-lg tracking-tight",
									children: m.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 line-clamp-2 text-sm text-muted",
									children: m.sanskrit.split("\n")[0]
								})]
							}) }, m.slug))
						})]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { MantraPage as component };
