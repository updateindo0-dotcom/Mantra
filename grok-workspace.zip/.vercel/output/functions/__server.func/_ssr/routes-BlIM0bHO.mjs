import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Search } from "../_libs/lucide-react.mjs";
import { n as SiteHeader, t as SiteFooter } from "./site-header-C_hDHpPg.mjs";
import { a as mantras, i as featured, o as searchMantras, r as Route$1 } from "./router-Dm72VQ5l.mjs";
import { n as cn, r as useFavorites, t as categories } from "./utils-CkWN9tQQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BlIM0bHO.js
var import_jsx_runtime = require_jsx_runtime();
function MantraCard({ mantra }) {
	const cat = categories.find((c) => c.id === mantra.category);
	const preview = mantra.sanskrit.split("\n")[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/mantra/$slug",
		params: { slug: mantra.slug },
		className: "group flex flex-col rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-150 ease-out hover:shadow-[var(--shadow-border-hover)] active:scale-[0.99]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-kicker text-muted uppercase",
				children: cat?.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-2 font-display text-xl tracking-tight group-hover:text-accent",
				children: mantra.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mantra-text mt-3 line-clamp-3 text-base text-ink/80",
				children: preview
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-muted",
				children: mantra.source
			})
		]
	});
}
function Home() {
	const { q, cat } = Route$1.useSearch();
	const ids = useFavorites((s) => s.ids);
	const query = q ?? "";
	const active = cat ?? "all";
	let list = query ? searchMantras(query) : mantras;
	if (active === "saved") list = list.filter((m) => ids.includes(m.slug));
	else if (active !== "all") list = list.filter((m) => m.category === active);
	const catMeta = categories.find((c) => c.id === active);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, { query }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "border-b border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-kicker text-muted uppercase",
							children: "देव · संप्रदाय"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex gap-2 overflow-x-auto pb-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatChip, {
									to: "all",
									label: "सभी",
									active: active === "all"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatChip, {
									to: "saved",
									label: "सहेजे",
									active: active === "saved"
								}),
								categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatChip, {
									to: c.id,
									label: c.title,
									active: active === c.id
								}, c.id))
							]
						})]
					})
				}),
				active === "all" && !query ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "border-b border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-kicker text-muted uppercase",
								children: "नित्य स्मरण"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-display text-3xl tracking-tight",
								children: "सबसे अधिक जपे जाने वाले"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
								children: featured.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MantraCard, { mantra: m }, m.slug))
							})
						]
					})
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-kicker text-muted uppercase",
							children: active === "saved" ? "आपकी माला" : catMeta ? catMeta.blurb : query ? "खोज" : "पूरा कोश"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-display text-3xl tracking-tight",
							children: active === "saved" ? "सहेजे मंत्र" : catMeta ? catMeta.title : query ? `“${query}”` : `${mantras.length} मंत्र`
						}),
						list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-8 max-w-md text-muted",
							children: active === "saved" ? "अभी कुछ सहेजा नहीं। किसी मंत्र पर हृदय चिह्न दबाएँ।" : "इस खोज से कोई मंत्र नहीं मिला।"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
							children: list.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MantraCard, { mantra: m }, m.slug))
						})
					]
				}) })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
function Hero({ query }) {
	const navigate = Route$1.useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-b border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl lg:grid-cols-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col justify-end px-4 py-10 sm:px-6 sm:py-16 lg:col-span-6 lg:py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "stagger-in max-w-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-kicker text-muted uppercase",
							children: "सनातन धर्म · मंत्र संग्रह"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-4 font-display text-5xl leading-display tracking-tight sm:text-6xl",
							children: "मंत्र कोश"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-lg leading-relaxed text-muted",
							children: "गायत्री से हनुमान चालीसा तक — देवनागरी, अर्थ, कब जपें, और एक माला का स्पर्श-गणना। वेद अनंत हैं; यह नित्य पाठ का द्वार है।"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative mt-8",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
								className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted",
								strokeWidth: 1.75
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "search",
								name: "q",
								value: query,
								placeholder: "गायत्री, शिव, शान्ति…",
								"aria-label": "मंत्र खोजें",
								className: "h-12 w-full rounded-md bg-surface pr-4 pl-10 text-base text-ink shadow-[var(--shadow-border)] outline-none placeholder:text-muted focus-visible:ring-2 focus-visible:ring-accent/40",
								onChange: (e) => {
									const value = e.target.value;
									navigate({
										search: (prev) => ({
											...prev,
											q: value ? value : void 0
										}),
										replace: true
									});
								}
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: "लिखते ही सूची छँटती है। श्रेणियाँ नीचे हैं।"
						})
					]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative min-h-64 lg:col-span-6 lg:min-h-96",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/temple.jpg",
					alt: "प्रभात में मंदिर का मंडप और दीप",
					className: "absolute inset-0 size-full object-cover outline outline-1 -outline-offset-1 outline-ink/10"
				})
			})]
		})
	});
}
function CatChip({ to, label, active }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/",
		search: {
			cat: to === "all" ? void 0 : to,
			q: void 0
		},
		className: cn("inline-flex h-11 shrink-0 items-center rounded-full px-4 text-sm transition-colors duration-150", active ? "bg-accent text-accent-fg" : "bg-surface text-ink shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]"),
		children: label
	});
}
//#endregion
export { Home as component };
