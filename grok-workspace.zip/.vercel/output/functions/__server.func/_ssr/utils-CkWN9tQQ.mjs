import { n as create, t as persist } from "../_libs/zustand.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-CkWN9tQQ.js
var categories = [
	{
		id: "vedic",
		title: "वेद व ॐ",
		blurb: "प्रणव और वैदिक मूल मंत्र"
	},
	{
		id: "nitya",
		title: "नित्य पाठ",
		blurb: "प्रातः, भोजन और दिनचर्या"
	},
	{
		id: "shanti",
		title: "शान्ति",
		blurb: "उपनिषद् के शान्ति मंत्र"
	},
	{
		id: "ganesha",
		title: "गणेश",
		blurb: "विघ्नहर्ता की वंदना"
	},
	{
		id: "shiva",
		title: "शिव",
		blurb: "रुद्र, मृत्युंजय, पञ्चाक्षर"
	},
	{
		id: "vishnu",
		title: "विष्णु राम कृष्ण",
		blurb: "नारायण, राम और महामंत्र"
	},
	{
		id: "devi",
		title: "देवी",
		blurb: "दुर्गा, लक्ष्मी, सरस्वती"
	},
	{
		id: "hanuman",
		title: "हनुमान",
		blurb: "चालीसा और बल-बुद्धि"
	},
	{
		id: "surya",
		title: "सूर्य",
		blurb: "सवितृ और आदित्य"
	},
	{
		id: "guru",
		title: "गुरु",
		blurb: "ज्ञान और गुरु-वंदना"
	}
];
var useFavorites = create()(persist((set) => ({
	ids: [],
	toggle: (id) => set((s) => ({ ids: s.ids.includes(id) ? s.ids.filter((x) => x !== id) : [...s.ids, id] }))
}), { name: "mantra-kosha-favs" }));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
//#endregion
export { cn as n, useFavorites as r, categories as t };
